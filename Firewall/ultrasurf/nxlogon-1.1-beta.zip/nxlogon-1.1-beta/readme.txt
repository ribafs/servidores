*****************************************************************
NxLOgon v1.1-beta
  Author : Jinhee Lee
  Homepage : http://www.nxfilter.org
  Contact : support@nxfilter.org
*****************************************************************

This is a single sign-on client of NxFilter package. It has
the same license policy as NxFilter.
